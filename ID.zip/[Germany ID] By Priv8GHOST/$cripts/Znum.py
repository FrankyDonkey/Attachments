﻿# $cript By Priv8Ghost
# xXx Zugangsnummer xXx
# Group: facebook.com/groups/pegMM
print('''
      |\---/|
      | o_o |
       \_^_/
 → Zugangsnummer
 → By Priv8GHOST
''')
import random
x = '0123456789'
print(random.choice(x),random.choice(x),random.choice(x),random.choice(x),random.choice(x),random.choice(x),sep='')