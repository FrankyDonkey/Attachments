# $cript By Priv8Ghost
# xXx Seriennummer ID xXx
# Group: facebook.com/groups/pegMM
print('''
    /\_/\           ___
   = o_o =_______    \ \     !Seriennummer ID!
    __^      __(  \.__) )    # By Priv8GHOST #
(@)<_____>__(_____)____/
''')
import random
x = input("Enter Letter (T OR L):")
a = input("Enter Letter (CAPITAL):")
b = input("Enter Letter (CAPITAL):")
c = input("Enter Letter (CAPITAL):")
print(x,random.randint(0,9),random.randint(0,9),random.randint(0,9),a,random.randint(0,9),random.randint(0,9),b,c,sep='')