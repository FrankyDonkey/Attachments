# $cript By Priv8Ghost
# xXx Seriennummer ID xXx
# Group: facebook.com/groups/pegMM
print('''
    /\_/\           ___
   = o_o =_______    \ \     !Seriennummer ID!
    __^      __(  \.__) )    # By Priv8GHOST #
(@)<_____>__(_____)____/
''')
import random
x = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
print(random.choice(x),random.choice(x),random.choice(x),random.choice(x),random.choice(x),random.choice(x),random.choice(x),random.choice(x),random.choice(x),sep='')